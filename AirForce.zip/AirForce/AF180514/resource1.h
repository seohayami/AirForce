//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// Resource.rc �Ŏg�p
//
#define IDD_DIALOG_NEWMAP               104
#define IDD_DIALOG_DEPLOY_ORG           106
#define IDD_DIALOG_DEPLOY               106
#define IDD_DIALOG2                     108
#define IDD_DIALOG1                     400
#define IDC_LIST1                       401
#define IDC_RADIO1                      402
#define IDC_DEPLOY_SPEED                403
#define IDC_RADIO2                      404
#define IDC_DEPLOY_BANK                 405
#define IDC_CHECK1                      406
#define IDC_DEPLOY_NOSE                 407
#define IDC_CHECK2                      408
#define IDC_LIST2                       1006
#define IDC_BUTTON1                     1007
#define IDC_BUTTON2                     1008
#define IDC_LIST3                       1009
#define IDC_BUTTON3                     1010
#define IDC_BUTTON4                     1011
#define IDC_PLAYERID                    1012
#define IDC_COMBO1                      1013
#define IDC_DEPLOY_ACMODEL              1015
#define IDC_DEPLOY_PILOTMODEL           1016
#define IDC_DEPLOY_ACNAME               1017
#define IDC_DEPLOY_COR_X                1018
#define IDC_DEPLOY_ALT                  1019
#define IDC_DEPLOY_COR_Y                1020
#define IDC_DEPLOY_HEADING              1021
#define IDC_SPIN1                       1022
#define IDC_DEPLOY_ALT_UD               1022
#define IDC_COMBO2                      1023
#define IDC_RICHEDIT21                  1024
#define IDC_GAME_PROCEED		1100
#define IDC_LV_GAME_FIRINGTBL		1101


#define IDS_LV_CN_FIRINGTBL_ATID	"Attacker ID"

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
