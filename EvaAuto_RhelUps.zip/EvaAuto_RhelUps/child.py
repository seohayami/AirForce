from time import sleep

print('child start')
sleep(1)
print('child end')
