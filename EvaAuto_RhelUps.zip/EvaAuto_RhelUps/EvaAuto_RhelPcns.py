#! 
# -*- coding:utf-8- -*-

import os
import sys
import codecs
import datetime


import invoke 
import winrm
import paramiko
import subprocess
import pyautogui
import time
import keyboard
import pywinauto

import urllib                       # need not pip
import requests                     # need not pip
from bs4 import BeautifulSoup       # beautiful soup 4, need not pip
import re                           # regular expression, need not pip

from selenium import webdriver      # selenium ver3.14.1, need to pip

from pysnmp.hlapi import *
from fabric import Connection
from winrm.protocol import Protocol

from sys import platform
#if platform == 'win32':
#    ns.configure({'run': {'shell': environ['COMSPEC']}})

from invoke import Context
from invoke import task
#Context._patched = True
#_orig_run = Context.run

#######################################################################
#
# Constants for EvaAuto
#
#######################################################################

d_evaSys = { 
        "nmc_ipaddr": "10.206.27.120",
        "pdu_outlet_ups": 3,
        "pc_workDir": r'C:\Users\masajiKume\Documents\programming\EvaAuto_RhelUps\ ',
        "pc_pcnsConfigFile": r'C:\Users\masajiKume\Documents\programming\EvaAuto_RhelUps\pcnsconfig.ini',
        "pc_eventLogFile": r'C:\Users\masajiKume\Documents\programming\EvaAuto_RhelUps\eventLog.htm',
        "pc_tmpFile": r'C:\Users\masajiKume\Documents\programming\EvaAuto_RhelUps\tmpFile.htm',
        "sv_pcnsInstDir": r'/opt/APC/PowerChute/group1/',
        }

d_mib = { "rPDUOutletControlOutletName1": "1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.1", 
          "rPDUOutletControlOutletName2": "1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.2", 
          "rPDUOutletControlOutletName3": "1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.3", 
          "rPDUOutletControlOutletName4": "1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.4", 
          "rPDUOutletControlOutletName5": "1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.5", 
          "rPDUOutletControlOutletName6": "1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.6", 
          "rPDUOutletControlOutletName7": "1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.7", 
          "rPDUOutletControlOutletName8": "1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.8", 
          "rPDUOutletControlOutletCommand" : '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4', 
          "rPDUOutletControlOutletCommand1": '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4.1', 
          "rPDUOutletControlOutletCommand2": '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4.2', 
          "rPDUOutletControlOutletCommand3": '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4.3', 
          "rPDUOutletControlOutletCommand4": '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4.4', 
          "rPDUOutletControlOutletCommand5": '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4.5', 
          "rPDUOutletControlOutletCommand6": '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4.6', 
          "rPDUOutletControlOutletCommand7": '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4.7', 
          "rPDUOutletControlOutletCommand8": '1.3.6.1.4.1.318.1.1.12.3.3.1.1.4.8' 
          }

d_mousePt= {
        # prefix for dictionary key
        #   r= RHEL
        #   w= Windows
        #   v= VMWare
        #   n= PowerChuteNetworkShutdown
        #   b= PowerChuteBusinessEdition
        #   c= Network Management Card
        #---------- GUI coordinate for RHEL ----------
            "r_application": (70, 30),
                "r_accessory": (70, 60),
                    "r_emacsEditor": (260, 60),
                    "r_gnomeEditor": (260, 90),
                    "r_gnomeTerm": (260, 120),
                    "r_screenShot": (260, 150),
                    "r_calculator": (260, 180),
                    "r_dictionary": (260, 210), 
                    "r_archive": (260, 240), 
                    "r_charMap": (260, 270),
                "r_internet": (70, 90),
                "r_graphics": (70, 120),
                "r_sound": (70, 150),
                "r_systemTool": (70, 180),
                "r_programming": (70, 210), 
                "r_uninstall": (70, 250),
            "r_basho": (160, 30),
            "r_system": (215, 30),
        #---------- GUI coordinate for Windows7 ----------
            "w_origin": (0, 0),
            "w_center": (682, 383),
            "w_unsecureURL_proceed": (203, 269),
            "w_unsecureURL_proceed0": (203, 288),
        #---------- GUI coordinate for PowerChuteNetworkShutdown ----------
            "n_logout": (80,336),
            "n_configEvent": (105, 184),
                "n_configEvent_onBattSD": (1235, 195),
                    "n_configEvent_onBattSD_yes": (547, 183),
                    "n_configEvent_onBattSD_lasts": (591, 232),
                    "n_configEvent_onBattSD_reset": (635, 275),
            "n_configWizWelcome_next": (795, 640),
            "n_logon_name": (708, 188),
            "n_logon_next": (794, 638),
            "n_configWizUps_ipaddr": (729, 329),
            "n_configWizMisc_turnoffUps": (712, 187),
            "n_configWizMisc_next": (794, 639),
            "n_configWizConf_apply": (793, 639),
            "n_configWizApply_next": (793, 639),
            "n_configWizSelOG_outlet": (703, 306),
            "n_configWizSelOG_on": (703, 319),
            "n_configWizSelOG_apply": (794, 641),
            "n_configWizSelOG1_outletGrp": (65, 203),
            "n_configWizSelOG1_outletOn": (65, 217),
            "n_configWizSelOG1_turnoffOutlet": (19, 253),
            "n_configWizSelOG1_apply": (33, 289),
            "n_configWizApplyOG_next": (794, 641),
            "n_configWizDone_finish": (929, 640),
        #---------- GUI coordinate for Network Management Card ----------
            "c_login_name": (840, 330),
            "c_logoff": (1072, 59),
            "c_config": (636,103),
                "c_config_outlet": (636, 129),
                    "c_config_outlet_main": (272, 238),
                        "c_config_outlet_main_poffDelay": (491, 269),
                        "c_config_outlet_main_apply": (245, 537),
                "c_config_security": (636, 378),
                    "c_config_security_sessionMan": (804, 384),
                    "c_config_security_localUser": (804, 429),
                        "c_config_security_localUser_man": (951, 437),
                "c_config_general": (636, 452),
                        "c_config_general_identification": (805, 455),
                        "c_config_general_datetime": (805, 483),
                            "c_config_general_datetime_mode": (952, 484),
                                "c_datetime_localComp": (277, 451),
                                "c_datetime_apply": (240, 658),
            "c_tests": (783, 102),
                "c_tests_ups": (783, 131),
                    "c_tests_selftest": (408, 344),
                    "c_tests_apply": (244, 413),
            "c_logs": (905, 103),
                "c_logs_events": (905, 127),
                    "c_logs_events_log": (1075, 133),
            "c_localUser_man_apc": (229, 221),
            "c_localUser_man_apc_pw": (579, 252),
            "c_apply": (241, 315),

        }

d_evaErrCode = {
        "evaluate_PCNS_succeeded": 0,
        "checkNMC_selftest_failed": 1000,
        "removePC_eventLogFile_failed": 1001,
        "setNMC_powerDelay_failed": 1002,
        "eva_outageShort_failed": 1003,
    }

#######################################################################
#
# class definition
#
#######################################################################
class myWatch:
    def __init__(self):
        self.start = datetime.datetime.now()

    def setStart(self):
        self.start = datetime.datetime.now()
        time.sleep(1)
        # this sleep(1) is necessary
        # time of log has no fraction
        # therefore if test start time is 12:00:00.111, the power-outage
        # will be loged at 12:00:00
        # the delta will be 12:00:00.000 - 12:00:00.111 = negative

    def getDelta(self, line):
        """
        Function:
        Argument:
        Return: 
            time difference (sec.) of
            (date_time of line) - self.start
            if line does not include date_time, then return (-1)
        """
        testDate = re.search('[0-9]{2}/[0-9]{2}/[0-9]{4}', line)
        testTime = re.search('[0-9]{2}:[0-9]{2}:[0-9]{2}', line)
#        print(line)
        if testDate and testTime:
            s_date = str(testDate.group())
            l_date = s_date.split('/')              # Month, Day, Year
            print("getDelta date= " + s_date + str(l_date))
            s_time = str(testTime.group())
            l_time = s_time.split(':')              # Hour, Min, Sec
            print("getDelta time= " + s_time + str(l_time))
        # Caution_180926: "if testDate" statement is necessary.
        #   Without it, in search miss case, testDate is a NoneType
        #   therefore it has no attribute of 'group' and you get AttributeError.
        #
            timeTestEnd = datetime.datetime(
                    int(l_date[2]), int(l_date[0]), int(l_date[1]), # Year, Month, Day
                    int(l_time[0]), int(l_time[1]), int(l_time[2])) # Hour, Min, Sec
            delta = timeTestEnd - self.start
            print(timeTestEnd)
            print(self.start)
            rtn = delta.seconds
            print(rtn)
        else:
            rtn = -1
        return rtn


#######################################################################
#
# Functions for general use
#
#######################################################################
def getDateTimeLines(lines):
    rtn = []
    for line in lines:
        testDate = re.search('[0-9]{2}/[0-9]{2}/[0-9]{4}', line)
        testTime = re.search('[0-9]{2}:[0-9]{2}:[0-9]{2}', line)
        if testDate and testTime:
            print(line)
#            rtn += line
# Pitfall_20181002: list.extend(string), list += string
#   extend of string appends each char of string
#   ex. string = "abc"  list = ["book", "pen"]
#       list += string returns 
#           ["book", "pen", "a", "b", "c"]
#       list.append(string) returns
#           ["book", "pen", "abc"]
#
            rtn.append(line)
    print("------------ rtn of getDateTimeLines --------------")
    print(rtn)
    return rtn

def areInLines(l_string, lines):
    """
    Function:
        check if l_string(list of string) are contained in lines
        the order of l_string must be the same as lines
    Arguments:
        l_string = list of string
        lines = list of string
    Return:
        True= Yes
        False = No
    """
    target = l_string.pop(0)
    line = ""
    result = True
    while True:
        if target in line:
            print("areInLines: found target= " + target)
            try:
                target = l_string.pop(0)
            except:
                return True
        else:
            print("areInLines: miss target= " + target)
            try:
                line = lines.pop(0)
                print("areInLines: new line= " + line)
            except:
                return False
    return False            
 

#######################################################################
#
# Functions for parsing HTML
#
#######################################################################
def getValueTableHtml(fp, mark, row, clm):
    """
    Function:
        read file "fp" of HTML source, and
        find a string of "mark", and
        get a value from specified number of rows below the mark and "clm"th column from left
    Argument:
        fp = file handle to HTML source file
        mark = string which is searched, and will be used as mark point
        row = integer which specifies how many rows below the mark point the value resides
        clm = integer which specifies how many columns from left the value resides
              clm is 0-based, which means leftmost column is clm = 0.
    Return:
        a string of the value
    """
    fp.seek(0)
    # Pitfall_180929: fp.seek(0) is required if you exec readlines several times
    #   for an opened file.
    #   Ater executing a readlines first time, the file pointer is pointing the tail 
    #   of the file. Without seek(0), the second readlines() returns null list.
    #   
    lines = fp.readlines()
    line = ""

    def findString(s):
        nonlocal lines
        nonlocal line
        while True:
            if s in line:
                i = line.find(s)
                line = line[i + len(s): ]
#                print("-----------------CURRENT LINE =" + line)
                return True
            else:
                try:
                    line = lines.pop(0)
                except:
                    return False
        return False            

    def getPrefix(s):
        nonlocal lines
        nonlocal line
        ans = ""
        while True:
            if s in line:
                i = line.find(s)
                ans += line[0:i]
                return ans
            else:
                ans += line
                try:
                    line = lines.pop(0)
                except:
                    return ""
        return ""            


    def tableRow():
        success = findString("<tr>")
        if not success:
            return False
        success = findString("</tr>")
        if not success:
            return False
        return True

    def tableData():
        success = findString("<td>")
        if not success:
            return False
        success = findString("</td>")
        if not success:
            return False
        return True

    #----------- def getValueTableHtml main starts here ----------
#    print(line)
#    print("-------")
#    print(lines)
#    print("------------------------ original lines above ---------------------------")
    success = findString(mark)
    if not success:
        print("getValueTableHtml: finding mark failed.....")
        return ""
#    print(line)
#    print("-------")
#    print(lines)
#    print("------------------------ marked lines above ---------------------------")
    success = findString("</tr>")
    if not success:
        print("getValueTableHtml: finding end of tr failed.....")
        return ""
    for i in range(row - 2):
        success = tableRow()
        if not success:
            print("getValueTableHtml: skipping a row failed.....")
            return ""
    success = findString("<tr>")
    if not success:
        print("getValueTableHtml: finding the target row failed.....")
        return ""
    for i in range(clm - 1):
        success = tableData()
        if not success:
            print("getValueTableHtml: skipping a data failed.....")
            return ""
    success = findString("<td>")
    if not success:
        print("getValueTableHtml: finding the target td failed.....")
        return ""
    s = getPrefix("</td>")
    return s


def catinateTD(lines):
    """
    Function:
        in HTML source lines, 
         (1) <tr is searched, 
         (2) following lines are concatinated into one line.
         (3) if </tr> is found then repeats from (1) 
    Argument:
        list of string, which is the source code of HTML
    Return:
        list of string, whose TD/td lines are concatinated into one line
    """
    line = ""
    rtn = []

    def findString(s, catMode = False):
        """
        Function:
            search the string
            until the string is found, 
                if catMode, line is concatinated to the last element of rtn
                otherwise, line is appended to the rtn
        Return:
            True= found the string
            False= not found the string
        """
        nonlocal lines
        nonlocal line
        nonlocal rtn
        while True:
            if s in line:
                i = line.find(s)
                rtn += line[0:i]
                line = line[i + len(s):]
                return True
            else:
                if catMode:
                    rtn[-1] += line.strip()
                else:
                    rtn += line
                try:
                    line = lines.pop(0)
                except:
                    return False
        return False            

    def tableRow():
        """
        Return:
            True= completed the row search
            False= still has more lines to be searched
        """
        success = findString("<tr", False)
        if not success:
            return True
        success = findString("</tr>", True)
        if not success:
            return True
        return False

    #----------- catinateTD main starts here ----------
    while True:
        completed = tableRow()
        if completed:
            return rtn



#######################################################################
#
# Functions for SNMP
#
#######################################################################

@task
def test(ctx):
    ctx.run('dir')

def run(command, **kwargs):
    if sys.platform == 'win32':
        kwargs['shell'] = os.environ['COMSPEC']
    return _orig_run(command, **kwargs)

def mySnmpGet(s_oid):
    (errorIndication, errorStatus, errorIndex, varBinds) = next(
        getCmd(SnmpEngine(),
            CommunityData('public', mpModel = 0),
            UdpTransportTarget(('10.206.27.100', 161)),
            ContextData() ,
            ObjectType(ObjectIdentity(s_oid)))
    )

    if errorIndication:
        print(errorIndication)
    elif errorStatus:
        print('%s at %s' % (errorStatus.prettyPrint(),
                        errorIndex and varBinds[int(errorIndex) -1][0] or '?'))
    else:
        for varBind in varBinds:
            print(' = '.join([x.prettyPrint() for x in varBind]))

def mySnmpSet(s_oid, val):
    (errorIndication, errorStatus, errorIndex, varBinds) = next(
        setCmd(SnmpEngine(),
#            CommunityData('public', mpModel = 0), 
            CommunityData('private', mpModel = 0), 
            UdpTransportTarget(('10.206.27.100', 161)),
            ContextData(),
#            ObjectType(ObjectIdentity(s_oid), 2)
#            ObjectType(ObjectIdentity(s_oid))
#            ObjectType(ObjectIdentity(s_oid), int(2))
#            ObjectType(ObjectIdentity(s_oid), int32(2))
            ObjectType(ObjectIdentity(s_oid), Integer32(val))
#            ObjectType(ObjectIdentity(s_oid), 0x00000002)
#            ObjectType(ObjectIdentity(s_oid), '2')
#            ObjectType(ObjectIdentity(s_oid), oct(2))
#            ObjectType(ObjectIdentity(s_oid), OctetString('00000002'))
#            ObjectType(ObjectIdentity(s_oid), OctetString('immediateOff'))
#            ObjectType(ObjectIdentity(s_oid), 'immediateOff')
#            ObjectType(ObjectIdentity(s_oid), OctetString(2))
#            ObjectType(ObjectIdentity(s_oid), OctetString('2'))
#            ObjectType(ObjectIdentity('SNMPv2-MIB', 'sysORDescr', 1), '2')
#            ObjectType(ObjectIdentity('SNMPv2-MIB', 'sysORDescr', 1), '2')
        )
    )
    if errorIndication:
        print(errorIndication)
    elif errorStatus:
        print('%s at %s' % (errorStatus.prettyPrint(),
                        errorIndex and varBinds[int(errorIndex) -1][0] or '?'))
    else:
        for varBind in varBinds:
            print(' = '.join([x.prettyPrint() for x in varBind]))

def cmdToPDU(cmd, outlet):
    """
    Function:
        send command to the smart PDU
    Arguments:
        cmd = 'on': turn on the specified outlet immediately
        cmd = 'off': turn off the specified outlet immediately
        outlet = id of the outlet (outlet can be from 1 to 8)
    Regurn:
        True= Success
        False= Fail
    """
    if outlet < 1 or outlet > 8:
        print("cmdToPDU: illegal outlet id. id = " + str(outlet))
        return False
    s_oid = "rPDUOutletControlOutletCommand" + str(outlet)
    if cmd == 'on':
        mySnmpSet(d_mib[s_oid], 1)  # 1= immediateOn
        return True
    elif cmd == 'off':
        mySnmpSet(d_mib[s_oid], 2)  # 2= immediateOff
        return True
    else:
        print("cmdToPDU: illegal command. cmd = '" + str(cmd) + "'")
        return False

#mySnmpGet('1.3.6.1.4.1.318.1.1.12.3.3.1.1.2.1')
#mySnmpGet(d_mib["rPDUOutletControlOutletName1"])
#mySnmpGet(d_mib["rPDUOutletControlOutletCommand3"])
#mySnmpSet(d_mib["rPDUOutletControlOutletCommand3"], 1)

## execute shell commands on remote REHL through paramiko
#ssh = paramiko.SSHClient()
#ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#ssh.connect('10.206.27.111', username='root', password='adminesd')
#ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command('ls -al')
#for line in ssh_stdout:
#    print(line, end='')
#
##ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command('ls -al')
##while not ssh_stdout.channel.exit_status_ready():
##    if ssh_stdout.channel.recv_ready():
##        alldata = ssh_stdout.channel.recv(1024)
##        while ssh_stdout.channel.recv_ready():
##            alldata += ssh_stdout.channel.recv(1024)
##        print(str(alldata, "utf8"))
#
#ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command('pwd ')
#for line in ssh_stdout:
#    print(line, end='')
#
#
## execute ftp commands through paramiko
#LOCALPATH = r"C:\\Users\masajiKume\Documents\programming\autoEvaRhelUps\autoEva_RhelPcns.py"
#REMOTEPATH = r'/root/Documents/automation/tmp.py'
#sftp = ssh.open_sftp()
#sftp.put(LOCALPATH, REMOTEPATH)
#sftp.close()
#
#ssh.close()

#######################################################################
#
# Functions for mouse and Keyboard
#
#######################################################################

def moveMouseTo(menu, t= 0.5):
    x = d_mousePt[menu][0]
    y = d_mousePt[menu][1]
    pyautogui.moveTo(x, y, duration=0.5)
    time.sleep(t)

def clickOn(menu, t= 0.5):
    x = d_mousePt[menu][0]
    y = d_mousePt[menu][1]
    pyautogui.moveTo(x, y, duration=0.5)
    time.sleep(1.5)
    pyautogui.click(button='left')
#    pyautogui.click(button='left')
    time.sleep(t)

#######################################################################
#
# Functions for Files
#
#######################################################################

def removePC_file(pathKey):
    """
    Function: 
        remove a specified file from PC
    Argument:
        pathKey = a string of dictionary key for 'd_evaSys[]' dictionary.
        d_evaSys[pathKey] must be defined as a file path 
    Return: 
        True= removed successfully
        False= failed
    """    
    
    os.remove(d_evaSys[pathKey])
    exist = os.path.isfile(d_evaSys[pathKey])
    if exist:
        return False
    else:
        return True


def findStrInFile(fp, str):
#    pass 
    fp.seek(0)
    lines = fp.readlines()
    for line in lines:
        if str in line:
            return line
    return ""
#                    testDate = re.search('[0-9]{2}/[0-9]{2}/[0-9]{4}', line)
#                    testTime = re.search('[0-9]{2}:[0-9]{2}:[0-9]{2}', line)

def removePC_eventLogFile():
    """
    Function: remove event log file from PC
    Return: True= success
            False= fail
    """
    return removePC_file("pc_eventLogFile")


#######################################################################
#
# Functions for Remote Shell
#
#######################################################################

def shellCmd(cmd) :
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('10.206.27.111', username='root', password='adminesd')
    ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command(cmd)
    rtn = ''
    err = ''
    for line in ssh_stdout:
#        print(line, end='')
        rtn += line
    for line in ssh_stderr:
        err += line
    ssh.close()
    return rtn, err

def exeScript(script, cmds) :
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('10.206.27.111', username='root', password='adminesd')
    print("ssh.connect completed.  ")


#   ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command(script, get_pty=True)
    ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command(script)
    print("ssh.exec_command completed.  ")
#    print("stdout= " + ssh_stdout.readlines())
#    print("stderr= " + ssh_stderr.readlines())
    time.sleep(1)
    for cmd in cmds:
        print("cmd= '" + cmd + "'.")
    for cmd in cmds:
        print("-----printing stdout for each cmd= " + cmd + ". -----\n")
        time.sleep(1)
#        ssh_stdin.write(cmd)
#        ssh_stdin.flush()
#        ssh_stdout.flush()
#        print(ssh_stdout.readlines())
    rtn = ''
    err = ''
    
    print("-----printing stdout -----\n")
    for line in ssh_stdout:
#        print(line, end='')
        rtn += line
    print("-----printing stderr -----\n")
    for line in ssh_stderr:
        err += line
    ssh.close()
    return rtn, err

def shellScript(script, cmds) :
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('10.206.27.111', username='root', password='adminesd')
    print("ssh.connect completed.  ")

    channel = ssh.get_transport().open_session()
    channel.get_pty()
    ssh_shell = channel.invoke_shell()
    time.sleep(3)

    msg = ''
#    if ssh_shell.recv_ready():
    if channel.recv_ready():
        msgTmp = channel.recv(9999).decode('utf-8')
        print("0. shellScript():msg= " + msgTmp)
        msg += msgTmp
        msg += '\r\n'
    else:
        print("shellScript():error:recv_ready() returns false")
        ssh.close()

    channel.send(script)
    time.sleep(2)
#    if ssh_shell.recv_ready():
    if channel.recv_ready():
        msgTmp = channel.recv(9999).decode('utf-8')
        print("1. shellScript():msg= " + msgTmp)
        msg += msgTmp
        msg += '\r\n'

    for cmd in cmds:
        print("shellScript() sending '" + cmd + "'. ")
        channel.send(str(cmd))
        time.sleep(2)
#        if ssh_shell.recv_ready():
        if channel.recv_ready():
                msgTmp = channel.recv(9999).decode('utf-8')
                print("R. shellScript():msg= " + msgTmp)
                msg += msgTmp
                msg += '\r\n'
        else:
            print("shellScript():error:recv_ready() returns false")
            ssh.close()
    ssh.close()
    return msg


#######################################################################
#
# Functions for ftp 
#
#######################################################################
def ftpPut(localPath, remotePath) :
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('10.206.27.111', username='root', password='adminesd')
    sftp = ssh.open_sftp()
    sftp.put(localPath, remotePath)
    sftp.close()
    ssh.close()
    return

def ftpGet(remotePath, localPath) :
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('10.206.27.111', username='root', password='adminesd')
    sftp = ssh.open_sftp()
    sftp.get(remotePath, localPath)
    sftp.close()
    ssh.close()
    return


def install_xrdp():
    localPath = r"C:\\Users\masajiKume\Documents\programming\rmpFiles\xrdp-0.6.1-4.el5.i386.rpm"
    remotePath = r'/tmp/xrdp-0.6.1-4.el5.i386.rpm'
    ftpPut(localPath, remotePath)
   
    shellCmd("rpm -ivh /tmp/xrdp-0.6.1-4.el5.i386.rpm")
    shellCmd("chkconfig xrdp on")
    shellCmd("service xrdp start")

def install_xrdp_ifnot():
    lines, errs = shellCmd("rpm -qa | grep 'xrdp'")
    if 'xrdp' in lines:
        print("info:xrdp already installed. skip installing xrdp")
    else:
        install_xrdp()

def openRemoteDesktop():
    # open Windows' remoteDeskTop
    subprocess.Popen([r'C:\\Windows\System32\mstsc.exe'])   # not wait for close of mstsc.exe
    # automate remoteDeskTop with pyautogui
    pyautogui.PAUSE = 1
    pyautogui.FAILSAFE = True
    (width, height) = pyautogui.size()
    pyautogui.moveTo(width, 0, duration=0.5)
    time.sleep(2)
    pyautogui.typewrite(['enter'])      # push "connect" in "Remote Desktop Connect" dialog
    pyautogui.typewrite(['left'])       # select Yes in "Remote Desktop Connect" dialog
    pyautogui.typewrite(['enter'])      # push "Yes" in "Remote Desktop Connect" dialog

#######################################################################
#
# Functions for PCNS
#
#######################################################################

def copyPCNS_LinuxToHD():
    print("copying PCNS CD data to Hard Drive.")
    print("------mkdir /tmp/pcns -----")
    lines, errs = shellCmd("mkdir /tmp/pcns/")
    print(lines, end="")
    print(errs, end="")
    print("------mkdir /tmp/pcns/Linux -----")
    lines, errs = shellCmd("mkdir /tmp/pcns/Linux")
    print(lines, end="")
    print(errs, end="")
    print("------cp /media /tmp/pcns/Linux/ -----")
    lines, errs = shellCmd("cp -fr /media/PCNS*/Linux/* /tmp/pcns/Linux/")
    print(lines, end="")
    print(errs, end="")
    time.sleep(10)  # wait for completion of the cp 

def install_PCNS():
    print("install_PCNS() is being called.....")
    cmds = []
    cmds.append("\r\ny\n")  # res to "pcns3.0.1.tar exists. do you want to overwrite?
    for i in range(15):
        cmds.append(" ")    # res to page down of contract statement
    cmds.append("yes\n")    # res to "Do you agree to the above license terms?"
    cmds.append("\n")       # res to "Please enter the installtion dir or press enter "
    cmds.append("Yes\n")    # res to "Are you sure you want to install PCSN to /opt...."
    cmds.append("\n")       # res to "Please enter java dir or press enter to install bundle java
    cmds.append("\n")       # res to "Please enter java dir or press enter to install bundle java
    cmds.append("\n")       # res to "Please enter java dir or press enter to install bundle java
#    lines, errs = shellCmd("cd /tmp/pcns/Linux")
#    lines, errs = shellScript("/tmp/pcns/Linux/install.sh", cmds)
    print("executing PCNS install.sh .....")
    msg = shellScript("cd /tmp/pcns/Linux; /tmp/pcns/Linux/install.sh \n", cmds)
                            # this script installs PCNS to /opt/APC/PowerChute and 
                            # copies jre to /opt/APC/PowerChute
                            # java version = 1.6.0_31
                            # jave SE Runtime Environment (build 1.6.0_31-b04)
                            # Java HotSpot Server VM (build 20.6-b01, mixed mode)
#Pitfall_180913: shellCmd("cd /tmp/pcns/Linux") does not work
#   after "cd", i did shellCmd("pwd") and it returned /root
#   i searched for the solution, and found that shellCmd("cd /tmp/pcns; pwd") worked.
#   parmiko creates an instance of shell, so if i execute two shellCmd's, then 
#   each command goes to different shell. that's why pwd returned /root
    time.sleep(6)

    if "Installation has completed" in msg:
        return True
    else:
        return False

def uninstall_PCNS():
    print("un-installing PCNS.")
    cmds = []
    cmds.append("Yes\n")    # res to "Are you sure you want to uninstall....?"
    msg = shellScript("/opt/APC/PowerChute/uninstall \n", cmds)
    if "Uninstallation completed" in msg:
        return True
    else:
        return False
        


def openGnomeTerm_gui():
    moveMouseTo("application", "rhel")
    pyautogui.click(button='left')
    time.sleep(1)

    moveMouseTo("accessory", "rhel")

    moveMouseTo("gnomeTerm", "rhel")
    pyautogui.click(button='left')

def install_PCNS_gui():
    openGnomeTerm_gui()

    pyautogui.typewrite('cd /tmp/pcns/Linux\n')     # failed
    keyboard.write("cd /tmp/pcns/Linux\n")          # failed
    keyboard.write("cd /tmp/pcns/Linux\n")          # failed
#Pitfall=180914: pyautogui does not support remote machines.
#   So I need to give up "xrdp + pyautogui" strategy.
#

def logon_PCNS():
    print("starting Internet Explorer")
    os.system("explorer https://10.206.27.111:6547")
    time.sleep(50)      # this takes time. measured = 40sec
    
    print("maximizing IE window so that button location would be fixed.....")
    pyautogui.press('f11')  # maximize the window of IE so that mouse coordinate is fixed.
    time.sleep(1)
    
    print("clicking Proceed button for security warning.....")
    clickOn("w_unsecureURL_proceed")
    clickOn("w_unsecureURL_proceed0")
    time.sleep(30)  # sometimes, this takes time. measured = 25sec
    
    #cmd = ["cd 'C:\\Program Files\Internet Explorer'",
    #        "iexplore.exe https://10.206.27.111:6547"]
    #subprocess.Popen(cmd, shell=True)
    
    #subprocess.check_call(['notepad'])     # wait for chttp://10.206.27.120/NMC/KQYirrpkDj3Zy9A1XO7Erw/factinfo.htmlose of notepad
    #subprocess.Popen([r'"C:\\Program Files\Internet Explorer\iexplore.exe" https://10.206.27.111:6547'], shell=True)
    #subprocess.Popen([r'iexplore.exe https://10.206.27.111:6547'])
    
    print("clicking Next button on Config.Wizard Welcome.....")
    clickOn("n_configWizWelcome_next")   # click 'next' button on Configuration Wizard Welcome
    time.sleep(1)
    
    print("entering name and password on Config.Wizard Secure.....")
    clickOn("n_logon_name")     # click 'name' box on logon
    time.sleep(1)
    pyautogui.typewrite('apc\t')
    time.sleep(1)
    pyautogui.typewrite('apc\n')
    time.sleep(1)


def set_PCNS_eventOnBat(toggle, shutdownDelay):
    """
    Function:
        manipulate GUI of PCNS, and 
        configure the ConfigureEvents->UPS On Battery
    Arguments:
        toggle: True = flip the checkbutton of Yes_I_want_to_shutdown
                False = do not chante the checkbutton
        shutdownDelay: value to be set in the event_lasts box
                if the value is negtive, then value is not changed
    Return:
        True = Successful
        False = Failed
    """
    print("set_PCNS_eventOnBat: loging on to PCNS")
    logon_PCNS()
    clickOn("n_configEvent")
    clickOn("n_configEvent_onBattSD")
    #clickOn("n_configEvent_onBattSD_reset")     # make sure 'yes' button is cleared
    if toggle:
        print("set_PCNS_eventOnBat: toggling yes radio button")
        clickOn("n_configEvent_onBattSD_yes")
    if shutdownDelay >= 0:
        print("set_PCNS_eventOnBat: setting lasts button")
        clickOn("n_configEvent_onBattSD_lasts")
        pyautogui.press(['backspace', 'backspace', 'backspace', 'backspace'])
        pyautogui.typewrite(str(shutdownDelay) + '\nt') # Shutdown if OnBatt lasts 60sec

    clickOn("n_logout")
    pyautogui.press('f11')                              # normalize the window of IE
    pyautogui.hotkey('ctrl', 'w')                       # shortcut for closing the tab of IE
    time.sleep(1)
    return True
    
def config_PCNS_event():
    """
    Function:
        (1) ftp get server's pcnsconfig.ini, and
        (2) Depending on the setting of the pcnsconfig.ini,
            manipulate GUI of PCNS on PC and configure 
            the ConfigureEvents-> UPS On Battery
                if Shutdown enabled && shutdownDelay==60, then do nothing
                if Shutdown enabled && shutdownDelay!=60, then set shutdownDelay=60
                if Shutdonw disabled, then enable Shutdown and set shutdownDelay=60
    Return:
        None
    """
    remotePath = d_evaSys["sv_pcnsInstDir"] + "pcnsconfig.ini"
    localPath = d_evaSys["pc_pcnsConfigFile"]
    ftpGet(remotePath, localPath)
    time.sleep(3)
    with codecs.open(d_evaSys["pc_pcnsConfigFile"], 'r', "utf-8") as fp:
        str = "event_PowerFailed_enableShutdown"
        rtn = findStrInFile(fp, str)
        if "true" in rtn:
            str = "event_PowerFailed_shutdownDelay"
            rtn = findStrInFile(fp, str)
            shutdownDelay = re.search('[0-9]+', rtn).group()
            if shutdownDelay == "":
                print("configure_PCNS_event: illegal event_PowerFailed_shutdownDelay.")
            elif int(shutdownDelay) == 60:  # enable == true && shutdownDelay == 60
                print("configure_PCNS_event: already enabled Shutdown, shutdownDelay==60.")
                print("configure_PCNS_event: skip setting.")
            else:                           # enable == true && shutdownDelay != 60
                print("configure_PCNS_event: already enabled Shutdown.")
                print("configure_PCNS_event: setting shutdownDelay only.")
                set_PCNS_eventOnBat(False, 60)
        elif "false" in rtn:                # enable == false
            print("configure_PCNS_event: enabling Shutdown, and setting shutdownDelay.")
            set_PCNS_eventOnBat(True, 60)
        else:
            print("configure_PCNS_event: illegal event_PowerFailed_enableShutdown.")
    '''
    logon_PCNS()
    clickOn("n_configEvent")
    clickOn("n_configEvent_onBattSD")
    clickOn("n_configEvent_onBattSD_reset")     # make sure 'yes' button is cleared
    clickOn("n_configEvent_onBattSD_yes")
    clickOn("n_configEvent_onBattSD_lasts")
    pyautogui.press(['backspace', 'backspace', 'backspace', 'backspace'])
    pyautogui.typewrite(str(60) + '\nt')        # Shutdown if OnBatt lasts 60sec
    pyautogui.press('f11')                      # normalize the window of IE
    pyautogui.hotkey('ctrl', 'w')               # shortcut for closing the tab of IE
    time.sleep(1)
    '''


def configure_PCNS_1st():
    logon_PCNS()
    print("clicking button 'next' on Config.Wizard Electrical Config.....")
    clickOn("n_logon_next")     # click 'name' box on logon
    time.sleep(1)


    print("entering ipaddr on config.Wizard UPS Detail.....")
    clickOn("n_configWizUps_ipaddr")     # click 'ipaddr' box on logon
    time.sleep(1)
    pyautogui.typewrite(d_evaSys["nmc_ipaddr"] + '\n')
    time.sleep(1)
    
    print("clicking turnoff UPS after shutdown on config.Wizard Misc.....")
    clickOn("n_configWizMisc_turnoffUps")    # click 'turnoff' radio button on wizard
    time.sleep(1)
    
    print("clicking button 'next' on config.Wizard Misc.....")
    clickOn("n_configWizMisc_next")     # click 'next' button on wizard
    time.sleep(1)
    
    print("clicking button 'apply' on config.Wizard Confirm.....")
    clickOn("n_configWizConf_apply")    # click 'apply' button on wizard
    time.sleep(30)      # this takes time, measured = 25sec
    
    moveMouseTo("w_center")

    print("clicking button 'next' on config.Wizard Applying Changes.....")
    clickOn("n_configWizApply_next")    # click 'next' button on wizard
    time.sleep(35)      # in some cases, this takes time, measured 30sec

    # --------------- Select Outlet Group success case -------------------
    print("clicking box 'outlet' on configWizard Select Outlet Group.....")
    clickOn("n_configWizSelOG_outlet")
    time.sleep(1)

    print("clicking pulldown menu 'on' on configWizard Select Outlet Group.....")
    clickOn("n_configWizSelOG_on")
    time.sleep(1)

    print("clicking button 'apply' on configWizard Select Outlet Group.....")
    clickOn("n_configWizSelOG_apply")
    time.sleep(10)

    # --------------- Select Outlet Group fail case -------------------
    clickOn("n_configWizSelOG1_outletGrp")
    clickOn("n_configWizSelOG1_outletOn")
    clickOn("n_configWizSelOG1_turnoffOutlet")
    clickOn("n_configWizSelOG1_apply")
    # -----------------------------------------------------------------
    print("clicking button 'next' on configWizard Apply Outlet Group.....")
    clickOn("n_configWizApplyOG_next")
    time.sleep(1)

    print("clicking button 'finish' on configWizard Done.....")
    clickOn("n_configWizDone_finish")
    time.sleep(1)

    clickOn("n_logout")
    pyautogui.press('f11')          # normalize the window of IE
    pyautogui.hotkey('ctrl', 'w')   # shortcut for closing the tab of IE
    time.sleep(1)

#######################################################################
#
# Functions for NMC
#
#######################################################################

def logon_NMC():
    print("starting Internet Explorer")
    os.system("explorer http://" + d_evaSys['nmc_ipaddr'] + "/")
    time.sleep(25)
    
    print("maximizing IE window so that button location would be fixed.....")
    pyautogui.press('f11')  # maximize the window of IE so that mouse coordinate is fixed.
    time.sleep(1)
    
    print("clicking name box on login dialog of NMC.....")
    clickOn("c_login_name")
    time.sleep(1)
    pyautogui.typewrite('apc\t')
    pyautogui.typewrite('apc\n')
    time.sleep(3)

def logoff_NMC():
    print("logoff_NMC() is being called.....")
    clickOn("c_logoff")
    time.sleep(1)
    pyautogui.press('f11')            # normalize the window of IE
    pyautogui.hotkey('ctrl', 'w')     # shortcut for closing the tab of IE
    time.sleep(1)

def adjustClockNMC():
    moveMouseTo("c_config")
    moveMouseTo("c_config_general")
    moveMouseTo("c_config_general_identification")
    moveMouseTo("c_config_general_datetime")
    clickOn("c_config_general_datetime_mode")
    clickOn("c_datetime_localComp")
    clickOn("c_datetime_apply")

def saveHtmlSource(path):
    """
    Function: HTML source code of the current IE window is saved 
                to "path"
    Argument: path = string of path to the saved file
    Prerequisite: (1) The current top window must be IE window.
                  (2) a file of "path" must be newly created, 
                so if "path" file already exists, you must delete it
                before calling this funcition
    """
    pyautogui.hotkey('ctrl', 'u')   # shortcut for showing HTML source of eventLog
    time.sleep(1)
    pyautogui.hotkey('ctrl', 's')   # shortcut for showing "save dialog"
    time.sleep(1)
    pyautogui.typewrite(path + '\n')
    time.sleep(1)
    pyautogui.hotkey('ctrl', 'w')   # shortcut for closing HTML source of eventLog

def saveNMC_eventLog():
    """
    Function:
    Argument:
    Return:
    Prerequisite:
        must be loged-on to NMC, and the window must be full-size(f11)
    """
#        pyautogui.press('f11')  # restore the window size of IE so that we can operate Win menu.
#        time.sleep(1)
#        pyautogui.hotkey('win', 'up')   # maximaize IE window size so that menu cordinate be fixed.
#        time.sleep(1)
    moveMouseTo("c_logs")
    moveMouseTo("c_logs_events")
    clickOn("c_logs_events_log")    # display eventLog window
    time.sleep(10)
    saveHtmlSource(d_evaSys["pc_eventLogFile"])
    '''
    pyautogui.hotkey('ctrl', 'u')   # shortcut for showing HTML source of eventLog
    time.sleep(1)
    pyautogui.hotkey('ctrl', 's')   # shortcut for showing "save dialog"
    time.sleep(1)
    pyautogui.typewrite(d_evaSys["pc_eventLogFile"] + '\n')
    time.sleep(1)
    pyautogui.hotkey('ctrl', 'w')   # shortcut for closing HTML source of eventLog
    '''

def eva_outageShort_checkGui_html():
    """
    Function: read a saved eventLogFile, search date_time lines,
                a test start time which Watch instance held is used to
                calculate delta(time diff between date_time of line and the start_time)
                and select only lines whose delta is 0 < delta < 60 (sec.)
                if the lines contain the spcified strings, then check succeeds.
                otherwise fails.
    return: True= check success
            False= check fail
    """
    global mywatch
    l_focus = []
    with codecs.open(d_evaSys["pc_eventLogFile"], 'r', "utf-16") as fp:
        lines = fp.readlines()
        print("---------- print original lines --------")
        print(lines)
#        lines = catinateTD(lines)
#        print("---------- print catinatedTD --------")
#        print(lines)
        lines = getDateTimeLines(lines)
        print("---------- print getDateTimeLines --------")
        print(lines)
        for line in lines:
            delta = mywatch.getDelta(line)
            if 0 <= delta < 60:
                l_focus.append(line)

    l_string = [
            "No longer on battery power",
            "On battery power"
            ]
    print("---------- print l_focus --------")
    print(l_focus)
    result = areInLines(l_string, l_focus)
    return result

def eva_outageShort_checkGui():
    """
    Return:
        True= passed
        False= failed
    """
    logon_NMC()
    saveNMC_eventLog()
    rtn = eva_outageShort_checkGui_html()
    logoff_NMC()
    success = removePC_eventLogFile()
    if not success:
        print("eva_outageShort_checkGui: fail to remove eventLog.")
        return False
    return rtn

def eva_outageShort_check():
    success = eva_outageShort_checkGui()
    if success:
        print("*** eva_outageShort_check: passed. ***")
    else:
        print("*** eva_outageShort_check: failed. ***")
    return success


def eva_outageShort(duration):
    """
    Function:
        Evaluation of short power-outage
    Argument:
        duration = duration of the power-outage (sec)
    Return:
        True= evaluation completes successfully with no Error
        False = evaluation fails
    """
    global mywatch
    mywatch.setStart()
    outlet = d_evaSys["pdu_outlet_ups"]
    success = cmdToPDU('off', outlet)
    if not success:
        return False
    time.sleep(duration)
    success = cmdToPDU('on', outlet)
    if not success:
        return False
    success = eva_outageShort_check()
    if not success:
        print("***** eva_outageShort failed *****")
    else:
        print("***** eva_outageShort passed *****")
    return success

def evaluate_PCNS():
    """
    Function: execute whole process of PCNS evaluation
    Return: return=0 if evaluation completes successfully
            return=error code if it fails
    """

    timeTestStart = datetime.datetime.now()
    timeTestEnd = datetime.datetime.now()

    def setNMC_sessionTimeout(i):
        if not i in range(61):
            print("setNMC_sessionTimeout: argument out of range.")
            sys.exit()

        moveMouseTo("c_config")
        moveMouseTo("c_config_security")
        moveMouseTo("c_config_security_sessionMan")
        moveMouseTo("c_config_security_localUser")
        clickOn("c_config_security_localUser_man")
        time.sleep(2)
        clickOn("c_localUser_man_apc")
        time.sleep(3)
        clickOn("c_localUser_man_apc_pw")
        pyautogui.typewrite('apc\t\t\t\t')
        pyautogui.typewrite(str(i) + "\n")
        time.sleep(1)
        clickOn("c_apply")

    def applyNMC_selftest():
        moveMouseTo("c_tests")
        clickOn("c_tests_ups")
        clickOn("c_tests_selftest")
        nonlocal timeTestStart
        timeTestStart = datetime.datetime.now()
        clickOn("c_tests_apply")
        time.sleep(20)



    def checkNMC_selftest():
        """
        Function: read a saved eventLogFile, search date-time string,
                    calculate a delta-time(= searched date-time - nonlocal timeTestStart),
                    if delta-time is small(or log was taken recently) then
                    search the string "Self-Test passed".
                    if found, return True
                    if not found for the all lines, then return False.
        return: True= selftest success
                False= selftest fail
        """
        with codecs.open(d_evaSys["pc_eventLogFile"], 'r', "utf-16") as fp:
        # Pitfall_180926: char coding of the source html file saved by IE->edit->source
        #   the charcter coding is utf-16, not utf-8 nor ascii nor shift_jis nor euc_jp
        #   without codecs.open(....., "utf-16"), text would be garbled.
        #
            lines = fp.readlines()
            for line in lines:
                if "Self" in line:
                    testDate = re.search('[0-9]{2}/[0-9]{2}/[0-9]{4}', line)
                    testTime = re.search('[0-9]{2}:[0-9]{2}:[0-9]{2}', line)
                    print(line)
                    if testDate and testTime:
                        s_date = str(testDate.group())
                        l_date = s_date.split('/')              # Month, Day, Year
                        print("date= " + s_date + str(l_date))
                        s_time = str(testTime.group())
                        l_time = s_time.split(':')              # Hour, Min, Sec
                        print("time= " + s_time + str(l_time))
                    # Caution_180926: "if testDate" statement is necessary.
                    #   Without it, in search miss case, testDate is a NoneType
                    #   therefore it has no attribute of 'group' and you get AttributeError.
                    #
                        timeTestEnd = datetime.datetime(
                                int(l_date[2]), int(l_date[0]), int(l_date[1]), # Year, Month, Day
                                int(l_time[0]), int(l_time[1]), int(l_time[2])) # Hour, Min, Sec
                        delta = timeTestEnd - timeTestStart
                        print(timeTestEnd)
                        print(timeTestStart)
                        print(delta.seconds)
                        if delta.seconds < 120:
                            print("***** checkNMC_selftest: found the recent log ******")
                            if "Self-Test passed" in line:
                                print("***** Self-Test passed. *****")
                                return True
        print("***** Self-Test failed. *****") 
        return False


#            print(lines)
#
#        with open(r"C:\Users\masajiKume\Documents\programming\EvaAuto_RhelUps\qwe1.htm", 'w') as fpw:
#            fpw.writelines(lines)

#        with codecs.open(r"C:\Users\masajiKume\Documents\programming\EvaAuto_RhelUps\UPS Network Management Card 2.htm", 'r', "utf-16") as fp:
#        with open(r"C:\Users\masajiKume\Documents\programming\EvaAuto_RhelUps\UPS Network Management Card 2.htm") as fp:
#            soup = BeautifulSoup(fp, 'html.parser')
#            soup = BeautifulSoup(fp, 'lxml')
#            soup = BeautifulSoup(fp, 'html5lib')
#            print(soup)
#            print(soup.prettify())
#            print("--------------------0")
#            print(soup.string)
#            print("--------------------1")
#            print(soup.title)
#            print("--------------------2")
#            print(soup.find_all(string="Schneider"))
#            print(soup.find_all(string="Self"))
#            print(soup.find_all(string="Web"))
#            print("--------------------3")
#            print(soup.p)
#        print(soup.find_all(re.compile("[0-9]+\:[0-9]+\:[0-9]+")))
#        print(soup.find_all(re.compile("[0-9]+")))
#        print(soup.find_all(re.compile("^b")))
#        for tag in soup.find_all(re.compile("^b")):
#            print(tag.name)
#        print(soup.find_all('b'))
#        pyautogui.press('f11')  # minimize the window of IE 
#        time.sleep(2)
#        pyautogui.hotkey('win', 'down')
#        time.sleep(2)
#        moveMouseTo("c_logs")
#        moveMouseTo("c_logs_events")
#        clickOn("c_logs_events_log")
#        time.sleep(2)


        #selenium 
        #driver = webdriver.Ie(r"C:\Program Files (x86)\IEDriverServer.exe")
        #print(driver.current_url)


    def setNMC_powerDelay(offDelay, onDelay):
        """
        Function:
            set powerOffDelay and powerOnDelay to NMC, and
            check if the values are really set 
            by reading HTML source
        Return:
            True =  set the values successfully
            False = check failed 
        """
        moveMouseTo("c_config")
        clickOn("c_config_outlet")
        clickOn("c_config_outlet_main")
        clickOn("c_config_outlet_main_poffDelay")
        pyautogui.press(['backspace', 'backspace', 'backspace', 'backspace'])
        pyautogui.typewrite(str(offDelay) + '\t\t' + str(onDelay))
        clickOn("c_config_outlet_main_apply")
        # pushing button "apply" moves window to config->outlet
        time.sleep(2)
        saveHtmlSource(d_evaSys["pc_tmpFile"])
        time.sleep(5)
        with codecs.open(d_evaSys["pc_tmpFile"], 'r', "utf-16") as fp:
            mark = "Power Off Delay"
            row = 2
            clm = 1
            v = getValueTableHtml(fp, mark, row, clm)
            if int(v) != offDelay:
                print("setNMC_powerDelay: setting offDelay failed.")
                print("\t exp= " + str(offDelay) + ".  act= " + str(v))
                return False
            mark = "Power Off Delay"
            row = 2
            clm = 3
            v = getValueTableHtml(fp, mark, row, clm)
            if int(v) != onDelay:
                print("setNMC_powerDelay: setting onDelay failed.")
                print("\t exp= " + str(onDelay) + ".  act= " + str(v))
                return False
        success = removePC_file("pc_tmpFile")
        if not success:
            print("setNMC_powerDelay: failed to remove tmp file")
            return False
        return True


    #---------- def evaluate_PCNS(): main starts here ----------
    logon_NMC()
#    setNMC_sessionTimeout(60)
    adjustClockNMC()
    applyNMC_selftest()
    saveNMC_eventLog()
    success = checkNMC_selftest()
    if not success:
        return d_evaErrCode["checkNMC_selftest_failed"]

    success = removePC_eventLogFile()
    if not success:
        return d_evaErrCode["removePC_eventLogFile_failed"]

    success = setNMC_powerDelay(150, 30)
    if not success:
        return d_evaErrCode["setNMC_powerDelay_failed"]
    else:
        print("*** evaluate_PCNS: setNMC_powerDelay successfully.***")

    logoff_NMC()

    success = eva_outageShort(3)
    if not success:
        return d_evaErrCode["eva_outageShort_failed"]
    else:
        print("*** evaluate_PCNS: eva_outageShort completed successfully.***")

    return d_evaErrCode["evaluate_PCNS_succeeded"]


####################################################################################
#   
#   EvaAuto for RHEL
#       main()
#
#
####################################################################################
print("starting EvaAuto for RHEL.....")
mywatch = myWatch()

'''
# install xrdp if it's not installed yet
print("installing xrdp.....")
install_xrdp_ifnot()

# open Windows' remoteDesktop
# and connect to the server
#openRemoteDesktop()

# copy "Linux" directory in CD to /tmp/pcns/Linux/
print("copying PCNS CD data to HD.....")
copyPCNS_LinuxToHD()

# install PCNS to /opt/APC/PowerChute/
print("installing PCNS.....")
result = install_PCNS()
if result == False:
    print("autoEva failed to install PCNS.")
    sys.exit()

# configure PCNS just after install of PCNS
print("configuring PCNS.....")
configure_PCNS_1st()

# configure PCNS: events: shutdown system on OnBattery
print("configuring PCNS enabling Shutdown.....")
config_PCNS_event()

# evaluate PCNS 
print("evaluating PCNS.....")
evaluate_PCNS()

'''


success = eva_outageShort(3)


'''
time.sleep(100)
# uninstall PCNS
print("uninstalling PCNS.....")
result = True
result = uninstall_PCNS()
if result == False:
    print("autoEva failed to uninstall PCNS.")
    sys.exit()
print("uninstalling PCNS successful.")
'''

## open Windows' remoteDeskTop
#subprocess.Popen([r'C:\\Windows\System32\mstsc.exe'])   # not wait for close of mstsc.exe
## automate remoteDeskTop with pyautogui
#pyautogui.PAUSE = 1
#pyautogui.FAILSAFE = True
#(width, height) = pyautogui.size()
#(x, y) = pyautogui.position()
#s_position = 'X: ' + str(x).rjust(4) + ' Y: ' + str(y).rjust(4)
#print(s_position, end='')
#
#pyautogui.moveTo(width, 0, duration=0.5)
#
#time.sleep(2)
#pyautogui.typewrite(['enter'])      # push "connect" in "Remote Desktop Connect" dialog
#pyautogui.typewrite(['left'])       # select Yes in "Remote Desktop Connect" dialog
#pyautogui.typewrite(['enter'])      # push "Yes" in "Remote Desktop Connect" dialog


##pyautogui.hotkey('altleft', 'p')
##pyautogui.alert(text='text alert', title='title alert', button='OK')
#time.sleep(1)
# click user name in "login to xrdp" dialog
#pyautogui.moveTo(750, 380, duration=1.0)
#pyautogui.doubleClick(button='left')
# enter user name in "login to xrdp" dialog
#pyautogui.typewrite('root\n')
#time.sleep(1)
#keyboard.write("root\n")
#time.sleep(1)
#pywinauto.keyboard.SendKeys('root\n')
#time.sleep(1)
#keyboard.write("adminesd\n")
# push cancel on "login to xrdp" dialog
#pyautogui.moveTo(760, 480, duration=1.0)
#pyautogui.doubleClick(button='left')
##Pitfall_180903: pyautogui.typewrite() does not work for Windows Login password enter.
##   I searched Web and found that keybord module solved the similar problem.
##   So keyboard.write() is used here instead of pyautogui.typewrite()
##   I dont know why pyautogui.typewrite does not work in this case.
##
#keyboard.write("\n")
#pyautogui.typewrite(['enter'])      # push OK on "connecting to pre-existing remote desktop"
#
##pyautogui.click(button='left')
#'''
#
#
#pyautogui.dragTo(1355, 300, duration=1.0)
#pyautogui.dragRel(0, 200, duration=1.0)




## try winrm
#print('001:dir command on Remote by winrm-------------success')
#'''
#s = winrm.Session('10.206.27.110', auth=('masajiKume', 'viewsonic012'))
##s = winrm.Session('10.206.27.110', auth=('Administrator', 'admin'))
##s = winrm.Session('10.206.27.110', auth=('masajiKume', 'viewsonic012'), transport='kerberos')
#r = s.run_cmd('ipconfig', ['/all'])
#print(r.status_code)
#print(r.std_out)
#'''
#p = Protocol(
#        endpoint='http://10.206.27.110:5985/wsman',
#        transport='ntlm',
#        username=r'masajiKume',
#        password='viewsonic012',
#        server_cert_validation='ignore')
#shell_id = p.open_shell()
##command_id = p.run_command(shell_id, 'ipconfig', ['/all'])
##command_id = p.run_command(shell_id, 'dir', ['/all'])
#command_id = p.run_command(shell_id, 'dir')
#std_out, std_err, status_code = p.get_command_output(shell_id, command_id)
#p.cleanup_command(shell_id, command_id)
#lines = std_out.splitlines()
#for line in lines:
#    print(line)
##print(std_out, status_code, end='')
#p.close_shell(shell_id)
#
#print('002:dir command on Remote by winrm-------------success')
#p = Protocol(
#        endpoint='http://10.206.27.110:5985/wsman',
#        transport='ntlm',
#        username=r'Administrator',
#        password='admin',
#        server_cert_validation='ignore')
#shell_id = p.open_shell()
#command_id = p.run_command(shell_id, 'dir')
#std_out, std_err, status_code = p.get_command_output(shell_id, command_id)
#p.cleanup_command(shell_id, command_id)
#lines = std_out.splitlines()
#for line in lines:
#    print(line)
#
#
#print('003:start application on Remote by winrm-------------failure')
#command_id = p.run_command(shell_id, r'start C:\\WINDOWS\system32\mspaint.exe')
#print('003a:start application on Remote by winrm-------------failure')
##std_out, std_err, status_code = p.get_command_output(shell_id, command_id)
#print('003b:start application on Remote by winrm-------------failure')
#p.cleanup_command(shell_id, command_id)
#lines = std_out.splitlines()
#for line in lines:
#    print(line)
## HungUp. i dont know the cause
#
#print('004------------------------------------------')
#print(std_out, status_code, end='')
#p.close_shell(shell_id)
#
#print('005:ftp by paramiko--------------------------success')
#HOST = '10.206.27.110'
#USER = 'Administrator'
#PSWD = 'admin'
#LOCALPATH = r"C:\\Users\masajiKume\Documents\programming\try_fabirc\try_fabric180824.py"
#REMOTEPATH = r'C:\\users\tmp.py'
## Pitfall_180831
## REMOTEPATH needs file name.
## according to the paramiko document, REMOTEPATH should be just a target directory name,
## but it causes IOError.
#
#ssh = paramiko.SSHClient()
#ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#ssh.connect(HOST, username=USER, password=PSWD)
#
#sftp = ssh.open_sftp()
#sftp.put(LOCALPATH, REMOTEPATH)
#sftp.close()
#
#ssh.close()
#
#
#print('006:subprocess on local--------------------------success')
#print('parent start')
#subprocess.check_call(['python', 'child.py'])
#print('parent end')
#
#print('open notepad ')
##subprocess.check_call(['notepad'])     # wait for close of notepad
#subprocess.Popen(['notepad'])           # not wait for close of notepad
#print('opened notepad ')
#
#print('open remoteDesktop ')
#subprocess.Popen([r'C:\\Windows\System32\mstsc.exe'])           # not wait for close of mstsc.exe
#print('opened remoteDesktop ')
#
#	
#print('007:pyautogui--------------------------')
#pyautogui.PAUSE = 1
#pyautogui.FAILSAFE = True
#(width, height) = pyautogui.size()
#(x, y) = pyautogui.position()
#s_position = 'X: ' + str(x).rjust(4) + ' Y: ' + str(y).rjust(4)
#print(s_position, end='')
#
#pyautogui.moveTo(width, 0, duration=0.5)
#
#time.sleep(2)
##pyautogui.alert(text='text alert', title='title alert', button='OK')
#pyautogui.typewrite(['enter'])      # push "connect" in "Remote Desktop Connect" dialog
#pyautogui.typewrite(['left'])       # select Yes in "Remote Desktop Connect" dialog
#pyautogui.typewrite(['enter'])      # push "Yes" in "Remote Desktop Connect" dialog
##pyautogui.hotkey('altleft', 'p')
##pyautogui.alert(text='text alert', title='title alert', button='OK')
#time.sleep(1)
##pyautogui.typewrite('admin\n')
#keyboard.write("admin\n")
#print('pyautogui 005')
##Pitfall_180903: pyautogui.typewrite() does not work for Windows Login password enter.
##   I searched Web and found that keybord module solved the similar problem.
##   So keyboard.write() is used here instead of pyautogui.typewrite()
##   I dont know why pyautogui.typewrite does not work in this case.
##
#pyautogui.typewrite(['enter'])
#keyboard.write("\n")
#pyautogui.typewrite(['enter'])      # push OK on "connecting to pre-existing remote desktop"
#
#pyautogui.typewrite('qwe.txt\n')
#keyboard.write('qwe.txt\n')
#
#'''
## double click a folder and open it ---------- success
#pyautogui.moveTo(40, 280, duration=1.0)
#pyautogui.doubleClick(button='left')
##pyautogui.click(button='left')
#'''
#
#
#pyautogui.dragTo(1355, 300, duration=1.0)
#pyautogui.dragRel(0, 200, duration=1.0)
#
#time.sleep(1)
#pyautogui.moveTo(30, 695, duration=1.0)
#pyautogui.click(button='left')
#
#'''
## based on www.fabfile.org
#c = Connection(host='10.206.27.110', user='masajiKume', port=22, connect_kwargs={"password":"viewsonic012"})
#result = c.run('dir', hide=True)
#print(result)
#msg = "Ran {0.command!r} on {0.connection.host}, got stdout:\n{0.stdout}"
#print(msg.format(result))
#
#
##c.run = run
##c = Connection(host='10.206.27.110', user='masajiKume', port=2202)
#
##env.shell = "Cmd.exe /C"
#
#test()
#result = c.run('dir')
#print(result)
#
#result = c.put('./fabfile.py', remote='/tmp/temp.py')
#print(result)
#
#
##result = c.run('cd C:\Intel')
##result = c.run('C:\\\WINDOWS\\\system32\\\whoami', shell_kwargs=platform.os.environ['COMSPEC'])
##result = c.run('C:/WINDOWS/system32/whoami')
#
#'''
######
